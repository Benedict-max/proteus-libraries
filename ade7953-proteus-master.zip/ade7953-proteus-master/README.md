# ade7953-proteus

Proteus Library for Analog Devices ADE7953 Single Phase Metering IC.
